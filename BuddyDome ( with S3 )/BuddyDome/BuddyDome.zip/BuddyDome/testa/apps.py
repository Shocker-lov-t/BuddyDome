from django.apps import AppConfig


class TestaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'testa'
